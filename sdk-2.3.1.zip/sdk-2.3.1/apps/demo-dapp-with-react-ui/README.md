# Demo dapp with @tonconnect/ui-react

Try it out https://tonconnect-sdk-demo-dapp.vercel.app/

## Learn more about Ton Connect
- https://docs.ton.org/develop/dapps/ton-connect/
- https://github.com/ton-connect/sdk/tree/main/packages/ui
