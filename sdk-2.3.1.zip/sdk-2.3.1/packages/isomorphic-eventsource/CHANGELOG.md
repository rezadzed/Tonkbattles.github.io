# Changelog @tonconnect/isomorphic-eventsource 

## [0.0.2](https://github.com/ton-connect/sdk/compare/isomorphic-eventsource-0.0.2-beta.0...isomorphic-eventsource-0.0.2) (2023-11-06)



## [0.0.2-beta.0](https://github.com/ton-connect/sdk/compare/isomorphic-eventsource-0.0.1...isomorphic-eventsource-0.0.2-beta.0) (2023-11-02)


### Bug Fixes

* **isomorphic-eventsource:** remove redundant 'typings' field from package.json and fix 'types' field ([2b7ff53](https://github.com/ton-connect/sdk/commit/2b7ff53eb81d336a190cab2438e060fc62e593b7))
