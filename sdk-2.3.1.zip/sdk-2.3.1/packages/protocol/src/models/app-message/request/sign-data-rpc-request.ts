export interface SignDataRpcRequest {
    method: 'signData';
    params: [string];
    id: string;
}
