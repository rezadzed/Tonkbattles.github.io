export interface DisconnectEvent {
    event: 'disconnect';
    id: number;
    payload: {};
}
