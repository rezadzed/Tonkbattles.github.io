declare namespace _fetch {}
declare const _fetch: typeof fetch;
export = _fetch;
