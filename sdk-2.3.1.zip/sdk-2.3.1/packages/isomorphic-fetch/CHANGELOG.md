# Changelog @tonconnect/isomorphic-fetch 

## [0.0.3](https://github.com/ton-connect/sdk/compare/isomorphic-fetch-0.0.2...isomorphic-fetch-0.0.3) (2023-11-06)



## [0.0.2](https://github.com/ton-connect/sdk/compare/isomorphic-fetch-0.0.2-beta.0...isomorphic-fetch-0.0.2) (2023-11-06)



## [0.0.2-beta.0](https://github.com/ton-connect/sdk/compare/isomorphic-fetch-0.0.1...isomorphic-fetch-0.0.2-beta.0) (2023-11-02)


### Bug Fixes

* **isomorphic-fetch:** remove redundant 'typings' field from package.json and fix 'types' field ([cb5630d](https://github.com/ton-connect/sdk/commit/cb5630d1154628f7509fb9f89aab15a296c95310))
