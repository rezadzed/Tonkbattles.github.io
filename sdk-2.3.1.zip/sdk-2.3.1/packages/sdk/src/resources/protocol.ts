export const PROTOCOL_VERSION = 2;
