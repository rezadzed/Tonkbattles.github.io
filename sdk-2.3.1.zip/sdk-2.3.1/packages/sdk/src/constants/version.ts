declare const TON_CONNECT_SDK_VERSION: string;

export const tonConnectSdkVersion = TON_CONNECT_SDK_VERSION;
