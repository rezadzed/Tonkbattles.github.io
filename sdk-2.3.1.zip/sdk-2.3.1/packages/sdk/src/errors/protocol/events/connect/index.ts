export { UserRejectsError } from 'src/errors/protocol/events/connect/user-rejects.error';
