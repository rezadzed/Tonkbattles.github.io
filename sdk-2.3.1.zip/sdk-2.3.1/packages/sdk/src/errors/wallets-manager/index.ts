export { FetchWalletsError } from './fetch-wallets.error';
