export { ParseHexError } from './parse-hex.error';
