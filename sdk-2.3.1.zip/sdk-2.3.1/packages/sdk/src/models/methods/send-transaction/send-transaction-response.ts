export interface SendTransactionResponse {
    /**
     * Signed boc
     */
    boc: string;
}
