export interface ConnectAdditionalRequest {
    /**
     * Payload for ton_proof
     */
    tonProof?: string;
}
